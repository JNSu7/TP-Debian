#!/bin/bash
mostrar_ayuda() {
	echo "Uso: $0 <origen> <destino>"
	echo "Ejemplo: $0 /var/log /backup_dir/"
}

if [[ "$1" == "-h" || "$1" == "--help" ]]; then
	mostrar_ayuda
	exit 0
fi

ORIGEN="$1"
DESTINO="$2"

if [[ -z "$1" || -z "$2" ]]; then
	echo "Error: faltan argumentos."
	mostrar_ayuda
	exit 1
fi

if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: ORIGEN no existe."
	exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: DESTINO no existe."
	exit 3
fi

FECHA=$(date +%Y%m%d)
PREFIJO=$(basename "$ORIGEN" | tr -d '/')
ARCHIVO="${DESTINO}/${PREFIJO}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO" -C "$ORIGEN" .

if [[ $? -eq 0 ]]; then
	echo "Backup creado: $ARCHIVO"
else
	echo "Error al crear el backup"
	exit 4
fi
